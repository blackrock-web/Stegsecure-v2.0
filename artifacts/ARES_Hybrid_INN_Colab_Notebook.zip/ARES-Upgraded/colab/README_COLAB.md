# ARES-Hybrid-INN Colab Training

## File
`ARES_Hybrid_INN_Colab_Full_Training.ipynb`

## Steps
1. Upload `ARES-Hybrid-INN_Upgraded.zip` to Google Drive folder `MyDrive/ARES_Hybrid_INN/`
2. (Optional) Put `kaggle.json` at `MyDrive/kaggle.json` for ImageNet-256
3. Open the `.ipynb` in Colab → Runtime → GPU (high RAM if possible)
4. Run all cells top to bottom

## Datasets
| Dataset | Source |
|---------|--------|
| CIFAR-10 | torchvision auto-download |
| SIPI misc | sipi.usc.edu/database/misc.zip |
| ImageNet-256 | Kaggle (needs API key) |

## Checkpoints (Drive)
```
MyDrive/ARES_Hybrid_INN/checkpoints/ares_hybrid_inn_best.pt
MyDrive/ARES_Hybrid_INN/exports/ares_hybrid_inn_best.pt
```

Resume is automatic when best.pt exists.

## After training — use best model locally
```bash
cp ares_hybrid_inn_best.pt ARES-Upgraded/models/hybrid/
cp ares_hybrid_inn_best.pt ARES-Upgraded/models/hybrid/ares_hybrid_inn.pt
```
